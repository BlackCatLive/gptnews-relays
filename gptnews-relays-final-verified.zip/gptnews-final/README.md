# GPT News Relay

Automated Telegram feed for genuinely free music-production resources.

Target: Minimal House, Deep Minimal, Rominimal/Romanian Minimal, Deep House,
Deep Tech, Tech House, Minimal Tech/Minimal Techno.

Priority: vocals/acapellas, Serum/Vital presets, sample packs, drums/one-shots/loops,
free VST/VST3/synths/effects, royalty-free material.

The relay rejects trials, demos, subscriptions, rent-to-own, paid-only offers,
and generic editorial/listicle pages. Google News is used only as a discovery layer;
results are accepted only when they resolve to a trusted production-resource host.

Runs every 20 minutes and can be started manually from GitHub Actions.
