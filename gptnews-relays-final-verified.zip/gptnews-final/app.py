import os
import re
import json
import time
import html
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.request import Request, urlopen
from urllib.parse import quote, urlsplit, urlunsplit
from xml.etree import ElementTree as ET

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
CHANNEL = os.getenv("TELEGRAM_CHANNEL", "@gptnews999").strip()
SEEN_FILE = "seen_v4.json"
MAX_POSTS_PER_RUN = 12
MAX_ITEMS_PER_SOURCE = 30

# Direct feeds + targeted Google News discovery.
# Google is only accepted when its final URL resolves to a trusted production
# resource, not a generic editorial/listicle site.
SOURCES = [
    ("Bedroom Producers Blog", "https://bedroomproducersblog.com/feed/"),
    ("Rekkerd", "https://rekkerd.org/feed/"),
    ("Google • free VST", "https://news.google.com/rss/search?q=" + quote('"free VST" plugin download music production') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • free samples", "https://news.google.com/rss/search?q=" + quote('"free sample pack" download') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • free vocals", "https://news.google.com/rss/search?q=" + quote('"free vocal pack" OR acapella download') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Serum presets", "https://news.google.com/rss/search?q=" + quote('"free Serum presets" download') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Vital presets", "https://news.google.com/rss/search?q=" + quote('"free Vital presets" download') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • free drums", "https://news.google.com/rss/search?q=" + quote('"free drum kit" OR "free one shots" download') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Minimal House", "https://news.google.com/rss/search?q=" + quote('"minimal house" free samples OR presets OR vocals') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Deep Minimal", "https://news.google.com/rss/search?q=" + quote('"deep minimal" free samples OR presets OR vocals') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Rominimal", "https://news.google.com/rss/search?q=" + quote('rominimal OR "Romanian minimal" free samples OR presets') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Deep/Tech House", "https://news.google.com/rss/search?q=" + quote('"deep house" OR "deep tech" OR "tech house" free samples OR presets') + "&hl=en-US&gl=US&ceid=US:en"),
    ("Google • Minimal Techno", "https://news.google.com/rss/search?q=" + quote('"minimal techno" free samples OR presets') + "&hl=en-US&gl=US&ceid=US:en"),
]

# Hosts allowed for Google discovery. Editorial domains are deliberately
# excluded unless added later with a specific product-page rule.
TRUSTED_HOSTS = {
    "bedroomproducersblog.com",
    "rekkerd.org",
    "kvraudio.com",
    "plugins4free.com",
    "vst4free.com",
    "vstplanet.com",
    "99sounds.org",
    "samplefocus.com",
    "freesound.org",
}

GENRE_POSITIVE = {
    "minimal house": 24, "deep minimal": 24, "rominimal": 28,
    "ro-minimal": 28, "romanian minimal": 26, "microhouse": 20,
    "micro house": 20, "minimal tech": 18, "minimal tech house": 20,
    "minimal techno": 14, "deep house": 14, "deep tech": 14,
    "tech house": 12, "underground house": 8, "groove": 5,
    "groovy": 5, "rolling": 5, "percussive": 7, "percussion": 6,
}

GENRE_NEGATIVE = {
    "dubstep": -18, "brostep": -20, "hardstyle": -16,
    "drum and bass": -10, "dnb": -10, "metal": -12, "rock": -10,
    "orchestral": -8, "cinematic": -7, "trap": -7,
}

PRODUCT = {
    "vocal pack": 24, "vocal samples": 22, "acapella": 22, "acapellas": 22,
    "vocals": 17, "vocal": 14,
    "serum presets": 22, "serum preset": 20,
    "vital presets": 22, "vital preset": 20,
    "sample pack": 17, "sample packs": 17, "samples": 8,
    "drum kit": 12, "drum kits": 12, "one-shot": 11, "one shot": 11,
    "loops": 8, "loop pack": 9, "free vst": 10, "free vst3": 10,
    "vst3": 6, "plugin": 6, "synth": 7, "midi": 6,
    "royalty-free": 7, "royalty free": 7,
}

FREE_POSITIVE = [
    "free download", "free to download", "available for free", "freebie",
    "free vst", "free plugin", "free sample", "free samples",
    "free sample pack", "free vocal", "free vocals", "free vocal pack",
    "free preset", "free presets", "free serum", "free vital",
    "royalty-free", "royalty free", "pay what you like", "name your price",
    "100% free", "completely free",
]

HARD_BAD = [
    "free trial", "trial version", "trial plugin", "trial", "demo version",
    "demo only", "subscription required", "requires subscription",
    "subscription", "membership required", "rent-to-own", "rent to own",
    "monthly plan", "annual plan", "paid only",
]

EDITORIAL_BAD = [
    "best free", "top 5", "top 10", "top 20", "top 50", "ultimate list",
    "roundup", "round-up", "list of", "guide to", "how to", "tutorial",
    "review", "comparison", "tips and tricks", "buyer guide",
]

TARGET_PRODUCT_WORDS = [
    "plugin", "vst", "vst3", "sample", "samples", "vocal", "vocals",
    "acapella", "preset", "presets", "serum", "vital", "drum",
    "one-shot", "one shot", "loop", "loops", "midi", "synth",
]

def clean(value):
    value = html.unescape(value or "")
    value = re.sub(r"<[^>]+>", " ", value)
    return re.sub(r"\s+", " ", value).strip()

def host_of(url):
    try:
        host = urlsplit(url).netloc.lower().split("@")[-1].split(":")[0]
        return host[4:] if host.startswith("www.") else host
    except Exception:
        return ""

def canonical(url):
    try:
        p = urlsplit(url)
        return urlunsplit((p.scheme, p.netloc.lower(), p.path.rstrip("/"), "", ""))
    except Exception:
        return url

def fetch(url, timeout=12):
    req = Request(url, headers={
        "User-Agent": "Mozilla/5.0 GPTNewsRelay/Final",
        "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml, */*",
    })
    with urlopen(req, timeout=timeout) as response:
        return response.read(), response.geturl()

def resolve_google(url):
    try:
        _, final_url = fetch(url, timeout=8)
        return final_url
    except Exception:
        return url

def parse_feed(source, feed_url):
    try:
        raw, final_url = fetch(feed_url)
        root = ET.fromstring(raw)
    except Exception as exc:
        print(f"FEED ERROR | {source} | {exc}", flush=True)
        return []

    result = []
    for node in root.iter():
        tag0 = node.tag.split("}")[-1].lower()
        if tag0 not in {"item", "entry"}:
            continue

        title = link = desc = date = ""
        for child in list(node):
            tag = child.tag.split("}")[-1].lower()
            text = clean(child.text)
            if tag == "title":
                title = text
            elif tag in {"description", "summary", "content"} and not desc:
                desc = text
            elif tag in {"pubdate", "published", "updated", "date"} and not date:
                date = text
            elif tag == "link":
                link = child.attrib.get("href", "") or text

        if title and link:
            result.append({
                "source": source,
                "title": title,
                "description": desc,
                "link": link,
                "date": date,
            })

    return result[:MAX_ITEMS_PER_SOURCE]

def translate_ru(text):
    text = clean(text)
    if not text or re.search(r"[А-Яа-яЁё]", text):
        return text
    try:
        api = (
            "https://translate.googleapis.com/translate_a/single"
            "?client=gtx&sl=auto&tl=ru&dt=t&q=" + quote(text[:900])
        )
        raw, _ = fetch(api, timeout=8)
        data = json.loads(raw.decode("utf-8"))
        translated = "".join(part[0] for part in data[0] if part and part[0])
        return translated.strip() or text
    except Exception as exc:
        print(f"TRANSLATE FALLBACK | {exc}", flush=True)
        return text

def load_seen():
    try:
        with open(SEEN_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return set(data if isinstance(data, list) else data.keys())
    except Exception:
        return set()

def save_seen(seen):
    with open(SEEN_FILE, "w", encoding="utf-8") as f:
        json.dump(list(seen)[-5000:], f, ensure_ascii=False)

def fingerprint(item):
    return hashlib.sha256(canonical(item["link"]).encode("utf-8")).hexdigest()

def score_item(item, resolved_url=""):
    text = (item["title"] + " " + item["description"]).lower()
    title = item["title"].lower()
    source = item["source"].lower()
    score = 0

    bad_hits = [x for x in HARD_BAD if x in text]
    if bad_hits:
        return -999, [], [], bad_hits

    if not any(x in text for x in FREE_POSITIVE):
        return -999, [], [], ["not clearly free"]

    if not any(x in text for x in TARGET_PRODUCT_WORDS):
        return -999, [], [], ["not a production resource"]

    genre_hits = []
    for term, points in GENRE_POSITIVE.items():
        if term in text or term in source:
            score += points
            genre_hits.append(term)

    for term, points in GENRE_NEGATIVE.items():
        if term in text:
            score += points

    product_hits = []
    for term, points in PRODUCT.items():
        if term in text:
            score += points
            product_hits.append(term)

    # Reject obvious editorial/listicle headlines.
    if any(term in title for term in EDITORIAL_BAD):
        score -= 35

    # Google is discovery only. Require a trusted final host.
    if source.startswith("google"):
        host = host_of(resolved_url)
        if not host or not any(host == h or host.endswith("." + h) for h in TRUSTED_HOSTS):
            return -999, genre_hits, product_hits, [f"untrusted host: {host or 'unknown'}"]

        # Even on trusted domains, reject generic listicles.
        if any(term in title for term in EDITORIAL_BAD):
            return -999, genre_hits, product_hits, ["editorial/listicle"]

    # Strong bonus when both target genre and desired product are present.
    if genre_hits and product_hits:
        score += 15

    # Small bonus for actual download language.
    if any(x in text for x in ["download", "grab", "get it", "available"]):
        score += 5

    return score, genre_hits, product_hits, []

def category(item):
    text = (item["title"] + " " + item["description"]).lower()
    if any(x in text for x in ["acapella", "vocal pack", "vocal sample", "vocals", "vocal"]):
        return "🎤 VOCALS", "#vocals"
    if any(x in text for x in ["serum preset", "serum presets", "vital preset", "vital presets", "preset"]):
        return "🎹 PRESETS", "#presets"
    if any(x in text for x in ["sample pack", "sample packs", "samples", "loop", "one-shot", "one shot"]):
        return "🥁 SAMPLES", "#samples"
    if any(x in text for x in ["drum kit", "drum kits", "drums", "percussion"]):
        return "🥁 DRUMS", "#drums"
    if any(x in text for x in ["vst", "vst3", "plugin", "synth"]):
        return "🔌 PLUGINS", "#plugins"
    if "midi" in text:
        return "🎼 MIDI", "#midi"
    return "🎛️ OTHER", "#other"

def telegram_send(text):
    payload = json.dumps({
        "chat_id": CHANNEL,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": False,
    }).encode()
    request = Request(
        f"https://api.telegram.org/bot{TOKEN}/sendMessage",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=15) as response:
        data = json.loads(response.read().decode("utf-8"))
    if not data.get("ok"):
        raise RuntimeError(data)

def build_post(item, genre_hits, product_hits, limited=False):
    tag, hashtag = category(item)
    ru_title = translate_ru(item["title"])
    ru_desc = translate_ru(item["description"][:450]) if item["description"] else ""

    genre_line = "🎯 <b>ПОД MINIMAL / DEEP / ROMINIMAL</b>\n" if genre_hits else ""
    free_line = "🟡 <b>FREE — LIMITED TIME</b>" if limited else "🟢 <b>FREE</b>"

    parts = [
        f"{tag} {hashtag}",
        "",
        f"<b>{html.escape(ru_title)}</b>",
        "",
        free_line,
        genre_line.rstrip(),
    ]
    if ru_desc:
        parts += ["", html.escape(ru_desc)]
    parts += [
        "",
        f"📌 {html.escape(item['source'])}",
        f"🔗 <a href=\"{html.escape(item['link'], quote=True)}\">Открыть материал</a>",
    ]
    return "\n".join(x for x in parts if x != "")

def main():
    if not TOKEN:
        raise SystemExit("ERROR: TELEGRAM_BOT_TOKEN is missing")
    if not CHANNEL:
        raise SystemExit("ERROR: TELEGRAM_CHANNEL is missing")

    print("START FINAL MULTI-SOURCE RELAY", flush=True)
    seen = load_seen()
    raw_items = []

    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = {pool.submit(parse_feed, s, u): s for s, u in SOURCES}
        for future in as_completed(futures):
            source = futures[future]
            try:
                items = future.result()
                print(f"FOUND {len(items)} | {source}", flush=True)
                raw_items.extend(items)
            except Exception as exc:
                print(f"SOURCE ERROR | {source} | {exc}", flush=True)

    unique = {}
    for item in raw_items:
        unique[fingerprint(item)] = item

    candidates = []
    for item in unique.values():
        fid = fingerprint(item)
        if fid in seen:
            continue

        resolved = item["link"]
        if item["source"].lower().startswith("google"):
            resolved = resolve_google(item["link"])
            # Keep the actual destination in Telegram when possible.
            if resolved and host_of(resolved) and host_of(resolved) != "news.google.com":
                item = dict(item)
                item["link"] = resolved

        score, genres, products, reasons = score_item(item, resolved)
        if score >= 20:
            text = (item["title"] + " " + item["description"]).lower()
            limited = any(x in text for x in [
                "limited time", "for a limited time", "until", "expires",
                "ends on", "today only", "this week"
            ])
            candidates.append((score, len(genres), len(products), item, genres, products, limited))

    # Genre relevance first, then product relevance, then total score.
    candidates.sort(key=lambda x: (x[1], x[2], x[0]), reverse=True)

    posted = 0
    errors = 0
    for score, genre_count, product_count, item, genres, products, limited in candidates[:MAX_POSTS_PER_RUN]:
        try:
            telegram_send(build_post(item, genres, products, limited))
            seen.add(fingerprint(item))
            posted += 1
            print(
                f"POSTED score={score} genre={genre_count} product={product_count} "
                f"| {item['source']} | {item['title']}",
                flush=True,
            )
            time.sleep(0.25)
        except Exception as exc:
            errors += 1
            print(f"TELEGRAM ERROR | {item['title']} | {exc}", flush=True)

    save_seen(seen)
    print(
        f"DONE published={posted} candidates={len(candidates)} "
        f"unique={len(unique)} errors={errors}",
        flush=True,
    )

if __name__ == "__main__":
    main()
